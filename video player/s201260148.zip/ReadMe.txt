
Tamir's video player!!

In order to run the player you need to type "./Tam2" + "video1Name.format" + "video2Name.format" + "video3Name.format".
You have to put at least one video. (if it didnt work properly or didnt work at all , try it again until it do). 

OPTIONS:

# Use the "r , b , g , w , c" keys to switch video colors:
 - r for red.
 - b for blue.
 - g for green.
 - w for white.
 - c for regular colors.

# Use "1 , 2 , 3" keys to switch between channels.(each video is played in different channel).

# Use "4 , 5 , 6" keys to display different videos: (Switches the video with out the audio)

 - 4 to display the video in channel 1.
 - 5 to display the video in channel 2.
 - 6 to display the video in channel 3.

#Use "7 , 8 , 9" keys to play different audio: (Switches the audio with out the video)

 - 7 to play the audio in channel 1.
 - 8 to play the audio in channel 2.
 - 9 to play the audio in channel 3.

Thanks!!


